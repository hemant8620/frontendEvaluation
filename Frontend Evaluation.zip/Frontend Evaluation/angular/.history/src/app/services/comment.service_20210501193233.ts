import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

const API_PREFIX = "/api";

@Injectable({
  providedIn: "root"
})
export class CommentService {

  public urls = {
    commentFeed: 'http://localhost:3001/api/comments',
    commentAdd: 'http://localhost:3001/api/comments'
  }

  constructor(private http: HttpClient) { }

  /**
   * Reset comments back to original state.
   */
  resetComments(): Observable<any> {
    return this.http.post(`${API_PREFIX}/reset-comments`, {});
  }

  getComment(): Observable<any> {
    return this.http.get(this.urls.commentFeed);
  }

  addComment(data): Observable<any> {
    return this.http.post(this.urls.commentAdd, data);
  }
}
