import { Component, OnInit } from "@angular/core";

import { CommentService } from "./../../services/comment.service";

@Component({
  selector: "app-comment-feed",
  templateUrl: "./comment-feed.component.html",
  styleUrls: ["./comment-feed.component.css"]
})
export class CommentFeedComponent implements OnInit {
  comments: Comment[];
  commentAdded: any;
  errorMessage = "";
  dataComment: any;
  searchKey: any;

  constructor(private commentService: CommentService) {}

  ngOnInit() {
    this.getComentList();
  }

  resetCommentFeed() {
    this.commentService.resetComments().subscribe()
  }

  getComentList() {
    this.commentService.getComment().subscribe(res => {
        this.dataComment = res;
        console.log(this.dataComment);
    })
  }

  addComment() {
    this.commentService.addComment({text:this.commentAdded}).subscribe(res => {
      console.log(res);
      this.getComentList();
    })
  }

  delete(id) {
    this.commentService.deleteComment(id).subscribe(res => {
      this.getComentList();
    })
  }

  search() {
    this.commentService.search(this.searchKey).subscribe(res => {
      this.dataComment = res;
      // this.getComentList();
    })
  }

  reset() {
    this.commentService.resetComments().subscribe(res => {
      
    })
  }
}
